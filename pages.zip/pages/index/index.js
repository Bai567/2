//index.js
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    banner: [
      // { url: '../../images/lb1.jpeg' },
      // { url: '../../images/lb1.jpeg' },
      // { url: '../../images/lb1.jpeg' }
    ],
    menu: [
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/扫一扫.png',
      //   name: '扫一扫'
      // },
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/种植管理.png',
      //   name: '种植管理'
      // },
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/田间管理.png',
      //   name: '田间管理'
      // },
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/加工管理.png',
      //   name: '加工管理'
      // },
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/采收管理.png',
      //   name: '采收管理'
      // },
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/查询管理.png',
      //   name: '查询管理'
      // },
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/运输管理.png',
      //   name: '运输管理'
      // },
      // {
      //   id: 1,
      //   iconUrl: '../../images/menu/销售管理.png',
      //   name: '销售管理'
      // }
    ],
    recommend:[]
  },


  getData:function(){
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var me=this;
    wx.cloud.callFunction({
      name: 'getOpenid',
      data: {
      },
      success: function (res) {
        //推文查询
        db.collection('article').get({
          success: function (result) {
            // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
            console.log(result.data);
            me.setData({
              recommend: result.data
            })
          }
        });
        //轮播查询
        db.collection('lb').get({
          success: function (result) {
            // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
            console.log(result.data);
            me.setData({
              banner: result.data
            })
          }
        });
        //菜单查询
        db.collection('menu').get({
          success: function (result) {
            // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
            console.log(result.data);
            me.setData({
              menu: result.data
            })
          }
        });
      },
      fail: console.error
    });

    
    
    

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})