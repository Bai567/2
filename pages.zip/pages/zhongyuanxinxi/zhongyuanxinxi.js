let listdata = ""
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取卡片数据
    let that = this
    wx.cloud.callFunction({
      name: "chaxunshuju",
      data: {
        databaselist: "zhongyuanxinxi"
      },
      success(res) {
        that.setData({
          listdata: res.result.data
        })
        console.log("数据获取成功", res)
      },
      fail(res) {
        console.log("数据获取失败", res)
      }
    })
  },

  // 删除身份卡片
  deleteData: function (e) {
    let that = this
    // 获取当前数据id
    var id;
    id = e.target.dataset.id;
    console.log(id);
    // 弹出提示框
    wx.showModal({
      title: '提示',
      content: '确定删除？',
      success: function (res) {
        if (res.confirm) {
          // 确定删除
          //调用云函数进行删除
          wx.cloud.callFunction({
            name: "shanchushuju",
            data: {
              databaselist: "zhongyuanxinxi",
              id: id
            },
            success(res) {
              that.onLoad()
              console.log("删除成功", res)
            },
            fail(res) {
              console.log("删除失败", res)
            }
          })
        } else {
          // 取消删除

        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})