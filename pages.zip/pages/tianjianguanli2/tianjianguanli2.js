// pages/tianjianguanli2/tianjianguanli2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:'当归',
    number:'11',
    method:'间作',
    address:'四川省金牛区',
    time:'2018-01-30至2020-01-30',
    manage1:'',
    manage2:'',
    content:''
  },

  save1:function(e){
    this.setData({
      manage1:e.detail.value
    })
  },
  
  save2:function(e){
    this.setData({
      manage2:e.detail.value
    })
  },

  save:function(e){
    this.setData({
      content:this.data.content+this.data.manage1+":" +" " +this.data.manage2+'\n'
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})