// pages/yaocaiku/yaocaiku.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: '',
    search: ''
  },

  // 页面跳转
  showDetail(e){
    
    let id = e.currentTarget.id;

    console.log(this.data.list[id])

    wx.navigateTo({
      url: '/pages/yaocaiku2/yaocaiku2?_id=' + this.data.list[id]._id,
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.cloud.callFunction({
      name: 'get',
      success:res=>{
        // console.log(res.result.data)
        this.setData({
          list: res.result.data
        })
      },fail:res=>{
        console.log(res)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})