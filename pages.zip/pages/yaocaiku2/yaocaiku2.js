// pages/yaocaiku2/yaocaiku2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: '',
    edit: false,
    // editList: ['', 'Angelica sinensis', '种子', '有性繁殖', '本地', '自产', '未审核'],
    editList: [
      { name: '三七', tips: '请输入药材名称'},
      { name: 'Angelica sinensis', tips: '拉丁名' },
      { name: '种子', tips: '繁殖材料' },
      { name: '有性繁殖', tips: '繁殖方式' },
      { name: '本地', tips: '繁殖地点' },
      { name: '自产', tips: '购销方式' }
    ]
  },

  // 删除
  erase(){
    wx.showModal({
      title: '删除后不可恢复',
      content: '确定要删除吗',
      showCancel: true,
      success:res=>{
        console.log(res.confirm)
        if(res.confirm){
          wx.cloud.callFunction({
            name: 'get',
            data: {
              type: 'del',
              _id: this.data.list._id
            },success:res=>{
              wx.showToast({
                title: '删除成功',
              })
            }
          })
        }
      }
    })
  },

  edit(){
    this.setData({
      edit: !this.data.edit
    })
  },

  getVal(e){
    // console.log(e)
    let arr = this.data.editList;
    // let id = e.currentTarget.id;
    arr[e.currentTarget.id].name = e.detail.value
    this.setData({
      editList: arr
    })
  },

  save(){
    console.log(this.data.editList)
    let event = this.data.editList
    wx.cloud.callFunction({
      name: 'get',
      data: {
        type: 'update',
        _id: this.data.list._id,
        name: event[0].name,
        latin: event[1].name,
        reproduction: event[2].name,
        reproduction_style: event[3].name,
        reproduction_point: event[4].name,
        sale: event[5].name,
      },success:res=>{
        // console.log(res)
        this.setData({
          edit: false
        })
        wx.showToast({
          title: '保存成功！',
        })
      },fail:err=>{
        console.log(err)
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    // console.log(options.id)
    wx.cloud.callFunction({
      name: 'get',
      data:{
        _id: options._id,
        type: 'item'
      },
      success:res=>{
        console.log(res.result.data)
        this.setData({
          list: res.result.data[0]
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})