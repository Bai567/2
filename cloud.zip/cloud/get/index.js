// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'test-yp8nv'
})

// 云函数入口函数
exports.main = async(event, context) => {
  const wxContext = cloud.getWXContext()

  if (event.type == 'item') {
    return await cloud.database().collection("yaocaiList").where({
      _id: event._id
    }).get()
  }

  if (event.type == 'del') {
    return await cloud.database().collection("yaocaiList").where({
      _id: event._id
    }).remove()
  }

  if (event.type == 'update') {
    return await cloud.database().collection("yaocaiList").where({
      _id: event._id
    }).update({
      data: {
        name: event.name,
        latin: event.latin,
        reproduction: event.reproduction,
        reproduction_style: event.reproduction_style,
        reproduction_point: event.reproduction_point,
        sale: event.sale,
      },
    })
  }
  return await cloud.database().collection("yaocaiList").get()
}